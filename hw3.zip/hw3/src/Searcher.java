//import org.apache.lucene.document.Document;
//import org.apache.lucene.index.DirectoryReader;
//import org.apache.lucene.index.IndexReader;
//import org.apache.lucene.queryparser.classic.QueryParser;
//import org.apache.lucene.search.*;
//
//public class Searcher {
//    String querystr = "p KENNEDY ADMINISTRATION PRESSURE ON NGO DINH DIEM TO STOP\n" +
//            "\n" +
//            "SUPPRESSING THE BUDDHISTS .";
//    Query q = new QueryParser(Helpers.TEXT_FIELD, analyzer).parse(querystr);
//    int hitsPerPage = 18;
//    IndexReader reader = DirectoryReader.open(index);
//    IndexSearcher searcher = new IndexSearcher(reader);
//    TopDocs docs = searcher.search(q,  Integer.MAX_VALUE);
//
//    ScoreDoc[] hits = docs.scoreDocs;
//
//        System.out.println("Found " + hits.length + " hits.");
//        for(int i=0;i<hits.length;++i) {
//        int docId = hits[i].doc;
//        Document d = searcher.doc(docId);
//        Explanation a = searcher.explain(q,docId);
//        System.out.println("*************************************************************************************");
//        System.out.println((i + 1) + ". " + d.get(Helpers.DOC_ID) + " score: " + hits[i].score);
//        System.out.println(a);
//        System.out.println("*************************************************************************************");
//    }
//}
